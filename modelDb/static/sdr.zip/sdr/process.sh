#指定使用bash执行脚本
#!/bin/bash
rm -f *.txt
rm -f data.res
list=`cat list.conf|tr ',' ' '`
#预处理生成txt文件
for i in `ls *.log|grep -v sdr.log`
do
	file_name=`echo $i|awk -F '.' '{print $1}'`
	for j in $list
	do
		list_name=`cat sdr.log|grep $j|tr -d ' '|awk -F '|' '{print $1}'`
		num=`cat $i |grep -i $j|tail -1|tr -d ' '|awk -F '|' '{print $2}'|tr -d [a-z]|tr -d [A-Z]`
		echo $list_name $num >> $file_name'.txt'
	done
done 
#针对txt文件进行排版
txt_name=`ls *.txt|sed -n 1p`
line=`cat $txt_name|wc -l`
#数组
a[${#a[@]}]='list'
for n in `ls *.txt|awk -F '.' '{print $1}'`
do
	a[${#a[@]}]=`echo $n`
done
#打印这个数组
echo ${a[@]} >> data.res
#清空数组
unset a
for k in `seq 1  $line`
do
	a[${#a[@]}]=`cat $txt_name|awk '{print $1}'|sed -n $k'p'`
	for m in `ls *.txt`
	do		
		a[${#a[@]}]=`cat $m |awk '{print $2}'|sed -n $k'p'`
	done
	echo ${a[@]} >> data.res
	unset a
done

cat data.res|tr ' ' ',' > data.csv
rm -f *.txt
